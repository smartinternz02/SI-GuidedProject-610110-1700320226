from flask import Flask, render_template, request
import pickle
import numpy as np
from keras.models import load_model
import pandas as pd

app = Flask(__name__,static_folder='static')

# Load the list of teams
teams = ['Australia', 'India', 'Bangladesh', 'New Zealand', 'South Africa', 'England', 'West Indies', 'Afghanistan', 'Pakistan', 'Sri Lanka']

# Load the list of encoded columns
encoded_cols = pickle.load(open('ohe_cols.pkl', 'rb'))

# Load model and scalers
model = load_model('T20_Totalitarian_Mastering_Score_Predictions1.h5', custom_objects=None, compile=True)
scaler_X = pickle.load(open('scaler.pkl', 'rb'))
scaler_y = pickle.load(open('scaler_y.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html', teams=teams)

@app.route('/get_bowling_teams/<selected_batting_team>')
def get_bowling_teams(selected_batting_team):
    # Exclude the selected batting team from the list
    bowling_teams = [team for team in teams if team != selected_batting_team]
    return {'bowling_teams': bowling_teams}

@app.route('/predict', methods=['POST'])
def predict():
    # Get user inputs
    batting_team = request.form['batting_team']
    bowling_team = request.form['bowling_team']
    city = request.form['city']
    current_score = float(request.form['current_score'])
    balls_left = float(request.form['balls_left'])
    wickets_left = float(request.form['wickets_left'])
    crr = float(request.form['crr'])
    last_five = float(request.form['last_five'])

    # Create DataFrame with the input data
    input_data = [[batting_team, bowling_team, city, current_score, balls_left, wickets_left, crr, last_five]]
    input_df = pd.DataFrame(input_data, columns=['batting_team', 'bowling_team', 'city', 'current_score', 'balls_left', 'wickets_left', 'crr', 'last_five'])

    # Apply one-hot encoding based on the loaded columns
    input_df_encoded = pd.get_dummies(input_df, columns=['batting_team', 'bowling_team', 'city'])

    # Ensure the columns match the ones used during training
    input_df_encoded = input_df_encoded.reindex(columns=encoded_cols, fill_value=0)

    # Scale features
    X_scaled = scaler_X.transform(input_df_encoded)

    # Reshape for the model
    X_reshaped = X_scaled.reshape(1, 1, X_scaled.shape[1])

    # Make prediction
    y_pred = model.predict(X_reshaped)

    # Inverse transform prediction
    y_pred = scaler_y.inverse_transform(y_pred)

    return render_template('predict.html', prediction=y_pred[0][0])

if __name__ == '__main__':
    app.run(debug=True)
